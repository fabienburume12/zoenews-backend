-- ====================================================
-- BASE DE DONNÉES - Blog Journalistique
-- ====================================================

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) UNIQUE NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(255),
  `avatar` VARCHAR(255),
  `role` VARCHAR(20) DEFAULT 'member',
  `status` VARCHAR(20) DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL,
  INDEX(`email`),
  INDEX(`role`)
);

CREATE TABLE IF NOT EXISTS `articles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) UNIQUE NOT NULL,
  `excerpt` TEXT,
  `content` LONGTEXT,
  `featured_image` VARCHAR(255),
  `status` VARCHAR(20) DEFAULT 'draft',
  `views_count` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `published_at` TIMESTAMP NULL,
  `deleted_at` TIMESTAMP NULL,
  FOREIGN KEY(`user_id`) REFERENCES `users`(`id`),
  FULLTEXT INDEX(`title`, `excerpt`, `content`),
  INDEX(`status`),
  INDEX(`slug`)
);

CREATE TABLE IF NOT EXISTS `comments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `article_id` INT NOT NULL,
  `user_id` INT,
  `author_name` VARCHAR(100),
  `author_email` VARCHAR(255),
  `content` TEXT,
  `status` VARCHAR(20) DEFAULT 'pending',
  `ip_address` VARCHAR(45),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(`article_id`) REFERENCES `articles`(`id`),
  FOREIGN KEY(`user_id`) REFERENCES `users`(`id`),
  INDEX(`status`),
  INDEX(`article_id`)
);

CREATE TABLE IF NOT EXISTS `shares` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `article_id` INT NOT NULL,
  `platform` VARCHAR(50),
  `user_id` INT,
  `ip_address` VARCHAR(45),
  `shared_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(`article_id`) REFERENCES `articles`(`id`),
  INDEX(`platform`),
  INDEX(`article_id`)
);

CREATE TABLE IF NOT EXISTS `views` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `article_id` INT NOT NULL,
  `user_id` INT,
  `ip_address` VARCHAR(45),
  `viewed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(`article_id`) REFERENCES `articles`(`id`),
  INDEX(`article_id`)
);

CREATE TABLE IF NOT EXISTS `newsletter_subscribers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `subscribed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `unsubscribed_at` TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100),
  `email` VARCHAR(255),
  `subject` VARCHAR(255),
  `message` TEXT,
  `ip_address` VARCHAR(45),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `rate_limits` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `key` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Données initiales
INSERT INTO `users` (username, email, password, full_name, role) VALUES 
('admin', 'admin@journaldigi.com', '$2y$12$qJAj9S5W8K1V8WwjQpJVd.K7n1H3E5Q9M2X8F5B1D3C2E9A4G6H7', 'Administrateur', 'admin');
