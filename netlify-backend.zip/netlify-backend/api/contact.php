<?php
header('Content-Type: application/json; charset=UTF-8');
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['name']) || empty($data['email']) || empty($data['message'])) {
        jsonResponse(['success' => false, 'message' => 'Champs requis'], 400);
    }
    
    // Insérer dans la BDD
    db()->insert('contact_messages', [
        'name' => Security::escape($data['name']),
        'email' => Security::escape($data['email']),
        'subject' => Security::escape($data['subject'] ?? ''),
        'message' => Security::escape($data['message']),
        'ip_address' => Security::getClientIP(),
        'created_at' => date('Y-m-d H:i:s')
    ]);
    
    jsonResponse(['success' => true, 'message' => 'Message envoyé']);
}

jsonResponse(['success' => false, 'message' => 'Méthode non supportée'], 405);
