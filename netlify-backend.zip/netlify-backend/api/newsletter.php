<?php
header('Content-Type: application/json; charset=UTF-8');
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$parts = explode('/', trim($_SERVER['PATH_INFO'] ?? '', '/'));
$action = $parts[0] ?? '';

// POST /api/newsletter/subscribe
if ($method === 'POST' && $action === 'subscribe') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['email'])) {
        jsonResponse(['success' => false, 'message' => 'Email requis'], 400);
    }
    
    if (!Security::validateEmail($data['email'])) {
        jsonResponse(['success' => false, 'message' => 'Email invalide'], 400);
    }
    
    // Vérifier si déjà inscrit
    $exists = db()->exists('newsletter_subscribers', 'email = ?', [$data['email']]);
    
    if (!$exists) {
        db()->insert('newsletter_subscribers', [
            'email' => Security::escape($data['email']),
            'subscribed_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    jsonResponse(['success' => true, 'message' => 'Abonnement réussi']);
}

jsonResponse(['success' => false, 'message' => 'Endpoint non trouvé'], 404);
