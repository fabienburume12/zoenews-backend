<?php
header('Content-Type: application/json; charset=UTF-8');
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$parts = explode('/', trim($path, '/'));
$action = end($parts);

$user = new User();

// POST /api/auth/login
if ($method === 'POST' && $action === 'login') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['email']) || empty($data['password'])) {
        jsonResponse(['success' => false, 'message' => 'Email et mot de passe requis'], 400);
    }
    
    $userData = $user->login($data['email'], $data['password']);
    
    if (!$userData) {
        jsonResponse(['success' => false, 'message' => 'Identifiants incorrects'], 401);
    }
    
    $user->setSession($userData);
    jsonResponse(['success' => true, 'data' => ['id' => $userData['id'], 'email' => $userData['email']]]);
}

// POST /api/auth/logout
if ($method === 'POST' && $action === 'logout') {
    User::logout();
    jsonResponse(['success' => true, 'message' => 'Déconnexion réussie']);
}

// GET /api/auth/profile
if ($method === 'GET' && $action === 'profile') {
    requireLogin();
    $currentUser = User::getCurrentUser();
    jsonResponse(['success' => true, 'data' => $currentUser]);
}

jsonResponse(['success' => false, 'message' => 'Endpoint non trouvé'], 404);
