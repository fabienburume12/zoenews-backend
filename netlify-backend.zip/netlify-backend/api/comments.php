<?php
header('Content-Type: application/json; charset=UTF-8');
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$parts = explode('/', trim($_SERVER['PATH_INFO'] ?? '', '/'));
$articleId = $parts[0] ?? null;
$action = $parts[1] ?? null;

// GET /api/:articleId/comments - Récupérer commentaires
if ($method === 'GET' && $articleId && !$action) {
    $comments = db()->fetchAll(
        'SELECT * FROM comments WHERE article_id = ? AND status = ? ORDER BY created_at DESC',
        [$articleId, 'approved']
    );
    jsonResponse(['success' => true, 'data' => $comments]);
}

// POST /api/:articleId/comments - Créer commentaire
if ($method === 'POST' && $articleId) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['author_name']) || empty($data['author_email']) || empty($data['content'])) {
        jsonResponse(['success' => false, 'message' => 'Champs requis'], 400);
    }
    
    $commentId = db()->insert('comments', [
        'article_id' => $articleId,
        'author_name' => Security::escape($data['author_name']),
        'author_email' => Security::escape($data['author_email']),
        'content' => Security::escape($data['content']),
        'status' => 'pending',
        'ip_address' => Security::getClientIP(),
        'created_at' => date('Y-m-d H:i:s')
    ]);
    
    jsonResponse(['success' => true, 'data' => ['id' => $commentId]]);
}

jsonResponse(['success' => false, 'message' => 'Endpoint non trouvé'], 404);
