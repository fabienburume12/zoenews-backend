<?php
header('Content-Type: application/json; charset=UTF-8');
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$parts = explode('/', trim($_SERVER['PATH_INFO'] ?? '', '/'));
$action = $parts[0] ?? '';
$id = $parts[1] ?? null;

$article = new Article();

if ($method === 'GET' && !$id && !$action) {
    $page = (int) (isset($_GET['page']) ? $_GET['page'] : 1);
    $perPage = (int) (isset($_GET['per_page']) ? $_GET['per_page'] : ARTICLES_PER_PAGE);
    
    $articles = $article->getPublished($page, $perPage);
    jsonResponse(['success' => true, 'data' => $articles]);
}

if ($method === 'GET' && $action === 'popular') {
    $limit = (int) (isset($_GET['limit']) ? $_GET['limit'] : 5);
    $articles = $article->getPopular($limit);
    jsonResponse(['success' => true, 'data' => $articles]);
}

if ($method === 'GET' && $action === 'search') {
    $query = isset($_GET['q']) ? $_GET['q'] : '';
    if (strlen($query) < 2) {
        jsonResponse(['success' => false, 'message' => 'Requête trop courte'], 400);
    }
    
    $results = $article->search($query);
    jsonResponse(['success' => true, 'data' => $results]);
}

if ($method === 'GET' && $id) {
    $data = $article->getById($id);
    if (!$data) {
        jsonResponse(['success' => false, 'message' => 'Article non trouvé'], 404);
    }
    
    $article->incrementViews($id);
    jsonResponse(['success' => true, 'data' => $data]);
}

if ($method === 'POST' && $id && $action === 'share') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    db()->insert('shares', [
        'article_id' => $id,
        'platform' => Security::escape($data['platform'] ?? ''),
        'user_id' => User::getCurrentUserId(),
        'ip_address' => Security::getClientIP(),
        'shared_at' => date('Y-m-d H:i:s')
    ]);
    
    jsonResponse(['success' => true]);
}

jsonResponse(['success' => false, 'message' => 'Endpoint non trouvé'], 404);
