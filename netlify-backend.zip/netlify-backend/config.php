<?php
/**
 * ====================================================
 * CONFIGURATION - HEROKU
 * ====================================================
 */

// Déterminer l'environnement
define('ENVIRONMENT', getenv('ENVIRONMENT') ?: 'production');
define('DEBUG_MODE', getenv('DEBUG_MODE') ?: false);

// BASE DE DONNÉES - Lire depuis JAWSDB_URL en production
if (getenv('JAWSDB_URL')) {
    $url = parse_url(getenv('JAWSDB_URL'));
    define('DB_HOST', $url['host']);
    define('DB_USER', $url['user']);
    define('DB_PASS', $url['pass']);
    define('DB_NAME', substr($url['path'], 1));
} else {
    // Développement local
    define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
    define('DB_USER', getenv('DB_USER') ?: 'root');
    define('DB_PASS', getenv('DB_PASS') ?: '');
    define('DB_NAME', getenv('DB_NAME') ?: 'journalism_blog');
}

// URLs
define('BASE_URL', getenv('BASE_URL') ?: 'http://localhost/');
define('ADMIN_URL', BASE_URL . 'admin/');
define('API_URL', BASE_URL . 'api/');

// Chemins
define('ROOT_PATH', __DIR__ . '/');
define('INCLUDES_PATH', ROOT_PATH . 'includes/');
define('API_PATH', ROOT_PATH . 'api/');
define('UPLOADS_PATH', ROOT_PATH . 'uploads/');

// SÉCURITÉ
define('JWT_SECRET', getenv('JWT_SECRET') ?: 'your_secret_key_here_change_in_production');
define('CSRF_TOKEN_LENGTH', 32);
define('PASSWORD_MIN_LENGTH', 8);

// PAGINATION
define('ITEMS_PER_PAGE', 20);
define('ARTICLES_PER_PAGE', 6);

// UPLOAD
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

// EMAIL - SMTP
define('MAIL_HOST', getenv('MAIL_HOST') ?: 'smtp.gmail.com');
define('MAIL_PORT', getenv('MAIL_PORT') ?: 587);
define('MAIL_USERNAME', getenv('MAIL_USERNAME') ?: 'your_email@gmail.com');
define('MAIL_PASSWORD', getenv('MAIL_PASSWORD') ?: 'your_password');
define('MAIL_FROM_NAME', getenv('MAIL_FROM_NAME') ?: 'Journaux Digitals');
define('MAIL_FROM_EMAIL', getenv('MAIL_FROM_EMAIL') ?: 'noreply@journaldigi.com');

// SITE
define('SITE_NAME', 'Journaux Digitals');
define('SITE_DESCRIPTION', 'Blog journalistique professionnel');
define('SITE_EMAIL', 'contact@journaldigi.com');

// SEO
define('OG_IMAGE', BASE_URL . 'images/og-image.png');
define('TWITTER_HANDLE', '@journaldigi');

// CORS - À adapter selon votre frontend
define('CORS_ORIGIN', getenv('CORS_ORIGIN') ?: '*');

// TIMEZONE
date_default_timezone_set('UTC');

// Démarrer la session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
    session_set_cookie_params([
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
}

// Charger les classes
require_once INCLUDES_PATH . 'Database.php';
require_once INCLUDES_PATH . 'Security.php';
require_once INCLUDES_PATH . 'User.php';
require_once INCLUDES_PATH . 'Article.php';
require_once INCLUDES_PATH . 'functions.php';

// Headers CORS
header('Access-Control-Allow-Origin: ' . CORS_ORIGIN);
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
