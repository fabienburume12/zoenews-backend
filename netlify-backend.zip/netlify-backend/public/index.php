<?php
require_once '../config.php';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = str_replace(rtrim(dirname(__FILE__), '/'), '', $path);

if (strpos($path, '/api/articles') === 0) {
    $_SERVER['PATH_INFO'] = str_replace('/api/articles', '', $path);
    require_once '../api/articles.php';
} elseif (strpos($path, '/api/auth') === 0) {
    $_SERVER['PATH_INFO'] = str_replace('/api/auth', '', $path);
    require_once '../api/auth.php';
} elseif (strpos($path, '/api/contact') === 0) {
    require_once '../api/contact.php';
} elseif (strpos($path, '/api/newsletter') === 0) {
    $_SERVER['PATH_INFO'] = str_replace('/api/newsletter', '', $path);
    require_once '../api/newsletter.php';
} elseif (strpos($path, '/api/comments') === 0) {
    $_SERVER['PATH_INFO'] = str_replace('/api/comments', '', $path);
    require_once '../api/comments.php';
} else {
    jsonResponse(['success' => false, 'message' => 'API non trouvée'], 404);
}
