# 🔌 BACKEND HEROKU - Blog Journalistique

## 📁 Structure

```
netlify-backend/
├── public/
│   └── index.php          # Routeur principal
├── api/
│   ├── articles.php       # Articles API
│   ├── auth.php           # Authentification
│   ├── comments.php       # Commentaires
│   ├── contact.php        # Contact
│   └── newsletter.php     # Newsletter
├── includes/
│   ├── Database.php       # Classe BDD
│   ├── Security.php       # Sécurité
│   ├── User.php           # Utilisateurs
│   ├── Article.php        # Articles
│   └── functions.php      # Fonctions globales
├── sql/
│   └── database.sql       # Structure SQL
├── config.php             # Configuration
├── Procfile              # Configuration Heroku
├── composer.json         # Dépendances PHP
└── .gitignore
```

## 🚀 Déploiement Heroku

### 1. Prérequis

- Compte Heroku
- Heroku CLI installé
- Git configuré

### 2. Déployer

```bash
# Login Heroku
heroku login

# Créer l'app
heroku create votre-app-name

# Ajouter MySQL gratuit
heroku addons:create jawsdb:kitefree

# Récupérer l'URL de la BDD
heroku config:get JAWSDB_URL

# Configurer les variables d'environnement
heroku config:set CORS_ORIGIN="https://votre-frontend.netlify.app"

# Déployer
git push heroku main

# Importer la BDD
heroku run bash
mysql < sql/database.sql
exit

# Voir les logs
heroku logs --tail
```

## 🔌 Endpoints API

```
GET  /api/articles?page=1&per_page=6
GET  /api/articles/popular?limit=5
GET  /api/articles/:id
GET  /api/articles/search?q=query
POST /api/articles/:id/share

GET  /api/comments/:articleId
POST /api/comments/:articleId

POST /api/auth/login
POST /api/auth/logout
GET  /api/auth/profile

POST /api/contact
POST /api/newsletter/subscribe
```

## 📝 Configuration

Modifier `config.php` ou les variables Heroku:

```bash
heroku config:set DB_HOST="..."
heroku config:set JWT_SECRET="votre_clé"
heroku config:set MAIL_PASSWORD="..."
```

## 📞 Support

Consultez NETLIFY_DEPLOYMENT.md pour le guide complet
