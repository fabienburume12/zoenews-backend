<?php
/**
 * ====================================================
 * FONCTIONS GLOBALES
 * ====================================================
 */

function getSetting($key, $default = '') {
    static $cache = [];
    
    if (isset($cache[$key])) {
        return $cache[$key];
    }

    $row = db()->fetchOne('SELECT setting_value FROM settings WHERE setting_key = ?', [$key]);
    $value = $row ? $row['setting_value'] : $default;
    
    $cache[$key] = $value;
    return $value;
}

function post($key, $escape = true) {
    if (!isset($_POST[$key])) return null;
    $value = $_POST[$key];
    return $escape ? Security::escape($value) : $value;
}

function get($key, $escape = true) {
    if (!isset($_GET[$key])) return null;
    $value = $_GET[$key];
    return $escape ? Security::escape($value) : $value;
}

function session($key) {
    return $_SESSION[$key] ?? null;
}

function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function truncate($text, $length) {
    if (!$text) return '';
    return strlen($text) > $length ? substr($text, 0, $length) . '...' : $text;
}

function dateFormat($date, $format = 'd M Y') {
    return date($format, strtotime($date));
}

function formatNumber($num) {
    if ($num >= 1000000) {
        return round($num / 1000000, 1) . 'M';
    } elseif ($num >= 1000) {
        return round($num / 1000, 1) . 'K';
    }
    return $num;
}

function timeAgo($date) {
    $time = strtotime($date);
    $now = time();
    $diff = $now - $time;

    if ($diff < 60) return 'il y a ' . $diff . 's';
    if ($diff < 3600) return 'il y a ' . round($diff / 60) . 'm';
    if ($diff < 86400) return 'il y a ' . round($diff / 3600) . 'h';
    if ($diff < 604800) return 'il y a ' . round($diff / 86400) . 'j';
    
    return dateFormat($date);
}

function redirect($url) {
    if (!Security::isValidRedirect($url)) {
        $url = BASE_URL;
    }
    header('Location: ' . $url);
    exit;
}

function requireLogin() {
    if (!User::isLoggedIn()) {
        jsonResponse(['success' => false, 'message' => 'Non authentifié'], 401);
    }
}

function requireRole($role) {
    if (!User::hasMinRole($role)) {
        jsonResponse(['success' => false, 'message' => 'Accès refusé'], 403);
    }
}

function logAction($action, $entityType, $entityId) {
    $userId = User::getCurrentUserId();
    db()->insert('logs', [
        'user_id' => $userId,
        'action' => $action,
        'entity_type' => $entityType,
        'entity_id' => $entityId,
        'ip_address' => Security::getClientIP(),
        'created_at' => date('Y-m-d H:i:s')
    ]);
}
