<?php
class User {
    const ROLE_SUPER_ADMIN = 'super_admin';
    const ROLE_ADMIN = 'admin';
    const ROLE_EDITOR = 'editor';
    const ROLE_JOURNALIST = 'journalist';
    const ROLE_MEMBER = 'member';
    const ROLE_VISITOR = 'visitor';

    public function login($email, $password) {
        $user = db()->fetchOne('SELECT * FROM users WHERE email = ? AND deleted_at IS NULL', [$email]);
        
        if (!$user || !Security::verifyPassword($password, $user['password'])) {
            return false;
        }

        if ($user['status'] !== 'active') {
            return false;
        }

        db()->update('users', ['last_login' => date('Y-m-d H:i:s')], 'id = ?', [$user['id']]);
        
        return $user;
    }

    public function create($data) {
        if (empty($data['email']) || empty($data['password']) || empty($data['username'])) {
            return false;
        }

        $data['password'] = Security::hashPassword($data['password']);
        $data['role'] = $data['role'] ?? self::ROLE_MEMBER;
        $data['status'] = 'active';
        $data['created_at'] = date('Y-m-d H:i:s');

        return db()->insert('users', $data);
    }

    public function getById($id) {
        return db()->fetchOne('SELECT * FROM users WHERE id = ? AND deleted_at IS NULL', [$id]);
    }

    public function getByEmail($email) {
        return db()->fetchOne('SELECT * FROM users WHERE email = ? AND deleted_at IS NULL', [$email]);
    }

    public function getByUsername($username) {
        return db()->fetchOne('SELECT * FROM users WHERE username = ? AND deleted_at IS NULL', [$username]);
    }

    public function setSession($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_logged_in'] = true;
    }

    public static function isLoggedIn() {
        return isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true;
    }

    public static function getCurrentUser() {
        if (!self::isLoggedIn()) return null;
        $user = new self();
        return $user->getById($_SESSION['user_id']);
    }

    public static function getCurrentUserId() {
        return $_SESSION['user_id'] ?? null;
    }

    public static function logout() {
        session_destroy();
    }

    public function updateProfile($userId, $data) {
        unset($data['password'], $data['email']);
        $data['updated_at'] = date('Y-m-d H:i:s');
        db()->update('users', $data, 'id = ?', [$userId]);
        return true;
    }

    public function changePassword($userId, $oldPassword, $newPassword) {
        $user = $this->getById($userId);
        
        if (!$user || !Security::verifyPassword($oldPassword, $user['password'])) {
            return false;
        }

        db()->update('users', ['password' => Security::hashPassword($newPassword)], 'id = ?', [$userId]);
        return true;
    }

    public function hasRole($userId, $role) {
        $user = $this->getById($userId);
        return $user && $user['role'] === $role;
    }

    public static function hasMinRole($minRole) {
        if (!self::isLoggedIn()) return false;
        
        $roles = [self::ROLE_VISITOR, self::ROLE_MEMBER, self::ROLE_JOURNALIST, self::ROLE_EDITOR, self::ROLE_ADMIN, self::ROLE_SUPER_ADMIN];
        $userRole = array_search($_SESSION['user_role'], $roles);
        $minRoleIndex = array_search($minRole, $roles);
        
        return $userRole !== false && $minRoleIndex !== false && $userRole >= $minRoleIndex;
    }
}
