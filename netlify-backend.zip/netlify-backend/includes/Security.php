<?php
/**
 * ====================================================
 * CLASSE SECURITY - Sécurité
 * ====================================================
 */

class Security {
    public static function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(CSRF_TOKEN_LENGTH));
        }
        return $_SESSION['csrf_token'];
    }

    public static function verifyCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    public static function escape($text) {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }

    public static function escapeAttr($text) {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }

    public static function stripTags($text) {
        return strip_tags($text);
    }

    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function validateURL($url) {
        return filter_var($url, FILTER_VALIDATE_URL) !== false;
    }

    public static function validatePassword($password) {
        $errors = [];
        
        if (strlen($password) < PASSWORD_MIN_LENGTH) {
            $errors[] = "Au moins " . PASSWORD_MIN_LENGTH . " caractères";
        }
        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = "Au moins une majuscule";
        }
        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = "Au moins une minuscule";
        }
        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = "Au moins un chiffre";
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }

    public static function validateFile($file, $allowedTypes) {
        if ($file['size'] > MAX_FILE_SIZE) {
            return false;
        }
        return in_array($file['type'], $allowedTypes);
    }

    public static function generateSafeFilename($filename) {
        $filename = pathinfo($filename, PATHINFO_FILENAME);
        $extension = pathinfo($filename, PATHINFO_EXTENSION);
        return time() . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    }

    public static function createSlug($text) {
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9]+/', '-', $text);
        return trim($text, '-');
    }

    public static function generateToken($length = 32) {
        return bin2hex(random_bytes($length / 2));
    }

    public static function getClientIP() {
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    public static function checkRateLimit($key, $attempts, $window) {
        $db = Database::getInstance();
        $key = hash('sha256', $key);
        $now = time();
        $since = $now - $window;

        $count = $db->count('rate_limits', 'key = ? AND created_at > FROM_UNIXTIME(?)', [$key, $since]);

        if ($count >= $attempts) {
            return ['allowed' => false, 'remaining' => 0];
        }

        $db->insert('rate_limits', [
            'key' => $key,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return ['allowed' => true, 'remaining' => $attempts - $count - 1];
    }

    public static function isValidRedirect($url) {
        return filter_var($url, FILTER_VALIDATE_URL) && 
               parse_url($url, PHP_URL_HOST) === parse_url(BASE_URL, PHP_URL_HOST);
    }
}
