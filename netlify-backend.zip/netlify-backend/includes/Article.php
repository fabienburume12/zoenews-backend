<?php
class Article {
    public function create($data) {
        $data['slug'] = Security::createSlug($data['title']);
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['status'] = $data['status'] ?? 'draft';
        
        return db()->insert('articles', $data);
    }

    public function getById($id) {
        return db()->fetchOne(
            'SELECT a.*, u.username, c.name as category_name 
             FROM articles a 
             LEFT JOIN users u ON a.user_id = u.id 
             LEFT JOIN categories c ON a.category_id = c.id 
             WHERE a.id = ? AND a.deleted_at IS NULL',
            [$id]
        );
    }

    public function getBySlug($slug) {
        return db()->fetchOne(
            'SELECT a.*, u.username, c.name as category_name 
             FROM articles a 
             LEFT JOIN users u ON a.user_id = u.id 
             LEFT JOIN categories c ON a.category_id = c.id 
             WHERE a.slug = ? AND a.status = "published" AND a.deleted_at IS NULL',
            [$slug]
        );
    }

    public function getPublished($page = 1, $perPage = 6) {
        $offset = ($page - 1) * $perPage;
        return db()->fetchAll(
            'SELECT a.*, u.username, c.name as category_name 
             FROM articles a 
             LEFT JOIN users u ON a.user_id = u.id 
             LEFT JOIN categories c ON a.category_id = c.id 
             WHERE a.status = "published" AND a.deleted_at IS NULL 
             ORDER BY a.published_at DESC 
             LIMIT ? OFFSET ?',
            [$perPage, $offset]
        );
    }

    public function getPopular($limit = 5) {
        return db()->fetchAll(
            'SELECT a.*, u.username, c.name as category_name 
             FROM articles a 
             LEFT JOIN users u ON a.user_id = u.id 
             LEFT JOIN categories c ON a.category_id = c.id 
             WHERE a.status = "published" AND a.deleted_at IS NULL 
             ORDER BY a.views_count DESC 
             LIMIT ?',
            [$limit]
        );
    }

    public function search($query) {
        $term = '%' . $query . '%';
        return db()->fetchAll(
            'SELECT a.*, u.username, c.name as category_name 
             FROM articles a 
             LEFT JOIN users u ON a.user_id = u.id 
             LEFT JOIN categories c ON a.category_id = c.id 
             WHERE a.status = "published" AND a.deleted_at IS NULL 
             AND (a.title LIKE ? OR a.excerpt LIKE ? OR a.content LIKE ?) 
             ORDER BY a.created_at DESC 
             LIMIT 20',
            [$term, $term, $term]
        );
    }

    public function getByCategory($categoryId, $page = 1, $perPage = 6) {
        $offset = ($page - 1) * $perPage;
        return db()->fetchAll(
            'SELECT a.*, u.username 
             FROM articles a 
             LEFT JOIN users u ON a.user_id = u.id 
             WHERE a.category_id = ? AND a.status = "published" AND a.deleted_at IS NULL 
             ORDER BY a.created_at DESC 
             LIMIT ? OFFSET ?',
            [$categoryId, $perPage, $offset]
        );
    }

    public function getByAuthor($userId, $page = 1, $perPage = 6) {
        $offset = ($page - 1) * $perPage;
        return db()->fetchAll(
            'SELECT a.*, c.name as category_name 
             FROM articles a 
             LEFT JOIN categories c ON a.category_id = c.id 
             WHERE a.user_id = ? AND a.status = "published" AND a.deleted_at IS NULL 
             ORDER BY a.created_at DESC 
             LIMIT ? OFFSET ?',
            [$userId, $perPage, $offset]
        );
    }

    public function incrementViews($articleId) {
        db()->execute('UPDATE articles SET views_count = views_count + 1 WHERE id = ?', [$articleId]);
    }

    public function countPublished() {
        return db()->count('articles', 'status = ? AND deleted_at IS NULL', ['published']);
    }

    public function countByCategory($categoryId) {
        return db()->count('articles', 'category_id = ? AND status = ? AND deleted_at IS NULL', [$categoryId, 'published']);
    }

    public function update($id, $data) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        db()->update('articles', $data, 'id = ?', [$id]);
        return true;
    }

    public function delete($id) {
        db()->update('articles', ['deleted_at' => date('Y-m-d H:i:s')], 'id = ?', [$id]);
        return true;
    }

    public function publish($id) {
        db()->update('articles', ['status' => 'published', 'published_at' => date('Y-m-d H:i:s')], 'id = ?', [$id]);
    }
}
